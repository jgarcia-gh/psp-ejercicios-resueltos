﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ejercicio13
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            label.Content = "Descargando";
            Task t = Task.Run(() =>
            {
                using (WebClient client = new WebClient())
                {
                    client.DownloadFile("https://releases.ubuntu.com/24.04.1/ubuntu-24.04.1-desktop-amd64.iso", "./ubuntu-24.04.1-desktop-amd64.iso");
                }
            });

            await t;
            label.Content = "Archivo descargado";
        }
    }
}
